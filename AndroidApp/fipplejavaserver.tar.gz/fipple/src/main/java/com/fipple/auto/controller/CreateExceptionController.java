package com.fipple.auto.controller;

import com.fipple.auto.logreader.DevLogReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by subodh on 18/8/17.
 */

@RestController
public class CreateExceptionController {

    @Autowired
    private DevLogReader reader;

    private final Logger log = LoggerFactory.getLogger(CreateExceptionController.class);
    public String nullException = null;

    @RequestMapping("/exp")
    public void greeting() {
        try{
            nullException.contains("aaa");
        }catch (Exception e){
            StringBuffer exp = new StringBuffer();
            exp.append("Exception -{ ");
            for(StackTraceElement traceElement : e.getStackTrace()){
                exp.append(traceElement.toString());
            }
            exp.append(" }-");
//            System.out.println();
            log.info(exp.toString());
        }
    }
}
