package com.fipple.auto.logreader;

import org.apache.commons.io.input.Tailer;
import org.apache.commons.io.input.TailerListenerAdapter;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;

import static org.apache.commons.io.input.Tailer.create;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Created by subodh on 18/8/17.
 */
@Component
public class DevLogReader {

    private final static Logger LOGGER = getLogger(DevLogReader.class);

    @Value("${logging.file}")
    private String filePath;

    @PostConstruct
    public void initialize() {
        //Tailer started
        LOGGER.info("================ Starting Tailer for Dev logs ============== " + filePath);
        create(new File(filePath), new LogListener(LOGGER), 1000, true);
        LOGGER.info("=============== Tailer is initialized for Dev logs ============");
    }
}


class LogListener extends TailerListenerAdapter {

    private final Logger LOGGER;
    private Tailer tailer;


    public LogListener(Logger logger) {
        this.LOGGER = logger;
    }

    @Override
    public void handle(String line) {

        try {
            if(line.contains("Exception -{")) {

                System.out.println("=============================== ****************************************** " + line);
//                line = line.replace("Exception -{ ","");
            }
        } catch (Exception e) {
            LOGGER.error("Error in reading log file:: ", e);
        }
    }

    @Override
    public void fileRotated() {
        LOGGER.info("File rotated.");
    }

    @Override
    public void init(final Tailer tailer) {
        this.tailer = tailer;
    }

    @Override
    public void fileNotFound() {
        LOGGER.error("File not found at path {}", tailer.getFile().getAbsolutePath());
        tailer.stop();
    }

    @Override
    public void handle(Exception ex) {
        LOGGER.error("Error consuming log entry ::", ex);
    }
}
