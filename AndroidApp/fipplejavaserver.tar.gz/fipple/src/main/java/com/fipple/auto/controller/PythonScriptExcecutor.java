package com.fipple.auto.controller;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * Created by subodh on 19/8/17.
 */
@RestController
public class PythonScriptExcecutor {

    @RequestMapping(value = "/user", method = RequestMethod.POST)
    public void executeScript(@RequestBody Credentials credentials) {

        String url = "http://94274426.ngrok.io/user/create";
        System.out.println("============== user called ==============");
        ObjectMapper mapperObj = new ObjectMapper();
        String json= "";
        try {
            json= mapperObj.writeValueAsString(credentials);
        } catch (IOException e) {
            e.printStackTrace();
        }
        StringEntity requestEntity = new StringEntity(
                json,
                ContentType.APPLICATION_JSON);


        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        StringEntity entity = null;
        try {
            entity = new StringEntity(json);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        httpPost.setEntity(entity);
        CloseableHttpResponse response = null;
        try {
            response = client.execute(httpPost);
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Runtime r = Runtime.getRuntime();
        try {
            r.exec("cmd /c python C:\\Users\\shashis\\Desktop\\hashCode\\test_fipple.py");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
