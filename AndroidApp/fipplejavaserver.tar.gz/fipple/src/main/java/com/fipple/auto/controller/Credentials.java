package com.fipple.auto.controller;

/**
 * Created by subodh on 19/8/17.
 */
public class Credentials {
    private String jira_user_name;
    private String dashboard_user_name;
    private String dashboard_password;
    private String outlook_user_name;
    private String outlook_password;
    private String device_token;

    public String getJira_user_name() {
        return jira_user_name;
    }

    public void setJira_user_name(String jira_user_name) {
        this.jira_user_name = jira_user_name;
    }

    public String getDashboard_user_name() {
        return dashboard_user_name;
    }

    public void setDashboard_user_name(String dashboard_user_name) {
        this.dashboard_user_name = dashboard_user_name;
    }

    public String getDashboard_password() {
        return dashboard_password;
    }

    public void setDashboard_password(String dashboard_password) {
        this.dashboard_password = dashboard_password;
    }

    public String getOutlook_user_name() {
        return outlook_user_name;
    }

    public void setOutlook_user_name(String outlook_user_name) {
        this.outlook_user_name = outlook_user_name;
    }

    public String getOutlook_password() {
        return outlook_password;
    }

    public void setOutlook_password(String outlook_password) {
        this.outlook_password = outlook_password;
    }

    public String getDevice_token() {
        return device_token;
    }

    public void setDevice_token(String device_token) {
        this.device_token = device_token;
    }
}
