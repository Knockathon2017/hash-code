package com.example.subodh.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.FirebaseApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    Button submittButton = null;
    Button activity2Button = null;

    public static final String url = "http://172.16.1.79:9090/user";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*activity2Button = (Button) this.findViewById(R.id.activity2);

        activity2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TimeSheetActivity.class);
                startActivity(intent);
            }
        });*/

        submittButton = (Button) this.findViewById(R.id.submit);
        submittButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText jiraEmailIdEditText = (EditText) findViewById(R.id.jira_email_id);
                EditText dashboardEmailIdEditText = (EditText) findViewById(R.id.dashboard_email_id);
                EditText dashboardPasswordEditText = (EditText) findViewById(R.id.dashboard_password);
                EditText outlookEmailIdEditText = (EditText) findViewById(R.id.outlook_email_id);
                EditText outlookPasswordEditText = (EditText) findViewById(R.id.outlook_password);


                HashMap<String, String> params = new HashMap<String, String>();
                params.put("jira_user_name", jiraEmailIdEditText.getText().toString().trim());
                params.put("dashboard_user_name", dashboardEmailIdEditText.getText().toString().trim());
                params.put("dashboard_password", dashboardPasswordEditText.getText().toString().trim());
                params.put("outlook_user_name", outlookEmailIdEditText.getText().toString().trim());
                params.put("outlook_password", outlookPasswordEditText.getText().toString().trim());
                params.put("device_token", MyApplication.deviceId);
                RequestQueue mRequestQueue = Volley.newRequestQueue(getApplicationContext());

                JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.POST,url,new JSONObject(params),
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                System.out.println("============== " + response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                System.out.println(error.getMessage());
                            }
                        });
                mRequestQueue.add(jsObjRequest);

            }
        });
    }
}
