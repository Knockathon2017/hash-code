package com.example.subodh.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by subodh on 19/8/17.
 */

public class TimeSheetActivity extends AppCompatActivity {

    public static final String url = "http://94274426.ngrok.io/timesheet/1";
    String currentDate = "";
    List<Result> resultList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timesheet);

        String intentData = getIntent().getStringExtra("json");
        System.out.println("========== intent data =========== " + intentData);


        StringRequest stringRequest = new StringRequest(url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        json = response;
                        try {
                            parseJson(response);
                            LinearLayout mainLayout = (LinearLayout) findViewById(R.id.linearlayout);
                            TextView tv = null;


                            for(Result result : resultList){
                                tv = (TextView) getLayoutInflater().inflate(R.layout.timesheetentry, mainLayout, false);
                                StringBuffer sb = new StringBuffer();

                                sb.append("Date : " + currentDate + "\n");
                                sb.append("Project Name : " + result.getProjectName() + "\n");
                                sb.append("Description : " + result.getDescription() + "\n");
                                sb.append("StartTime : " + result.getStartTime() + "\n");
                                sb.append("EndTime : " + result.getEndTime() + "\n");

                                tv.setText(sb.toString());
                                mainLayout.addView(tv);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void parseJson(String json) throws JSONException {
        JSONObject jObject = new JSONObject(json);

        currentDate = jObject.getString("created_date");

        JSONArray jsonArray = jObject.getJSONArray("result");

        resultList = new ArrayList<>();

        for(int i = 0 ; i < jsonArray.length() ; i++){
            JSONObject object = jsonArray.getJSONObject(i);
            Result result = new Result();

            result.setDescription(object.getString("description"));
            result.setEndTime(object.getString("end_time"));
            result.setProjectName(object.getString("project_name"));
            result.setStartTime(object.getString("start_time"));

            resultList.add(result);

        }
    }
}
