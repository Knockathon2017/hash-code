package com.example.subodh.myapplication;

import android.app.Application;
import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;

/**
 * Created by subodh on 19/8/17.
 */

public class MyApplication extends Application {

    private static MyApplication mInstance;

    public static String deviceId = "";

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        try {
            deviceId = FirebaseInstanceId.getInstance().getToken();
            System.out.println("=============== FirebaseInstanceId.getInstance().getToken(); ================ " + FirebaseInstanceId.getInstance().getToken());
        } catch (Exception e) {
        }
    }

    public static Context getInstance() {
        return mInstance;
    }
}